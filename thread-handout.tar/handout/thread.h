
void printHistogram(int *hist, int n);

void *histo_0(void *vargp);

void *histo_1(void *vargp);

void *histo_2(void *vargp);

void *histo_3(void *vargp);

void *histo_4(void *vargp);

void *histo_5(void *vargp);

