/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_396()
{
    return 2496104776U;
}

unsigned addval_159(unsigned x)
{
    return x + 3347663024U;
}

unsigned addval_218(unsigned x)
{
    return x + 2277740632U;
}

unsigned getval_148()
{
    return 3348125815U;
}

void setval_322(unsigned *p)
{
    *p = 3347663125U;
}

unsigned getval_421()
{
    return 2421738029U;
}

unsigned getval_288()
{
    return 3848126808U;
}

void setval_398(unsigned *p)
{
    *p = 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_352(unsigned x)
{
    return x + 2430634312U;
}

unsigned addval_278(unsigned x)
{
    return x + 2430634312U;
}

unsigned getval_333()
{
    return 2430650696U;
}

void setval_216(unsigned *p)
{
    *p = 3281047241U;
}

void setval_340(unsigned *p)
{
    *p = 3525362305U;
}

void setval_132(unsigned *p)
{
    *p = 3682914697U;
}

unsigned addval_160(unsigned x)
{
    return x + 3227566729U;
}

void setval_411(unsigned *p)
{
    *p = 2294403465U;
}

unsigned addval_146(unsigned x)
{
    return x + 3229139593U;
}

void setval_442(unsigned *p)
{
    *p = 3677933953U;
}

unsigned getval_200()
{
    return 3469287073U;
}

unsigned getval_228()
{
    return 3676885385U;
}

unsigned addval_370(unsigned x)
{
    return x + 3285305669U;
}

unsigned getval_173()
{
    return 3376992649U;
}

unsigned addval_294(unsigned x)
{
    return x + 3281047177U;
}

unsigned getval_154()
{
    return 3229929865U;
}

unsigned getval_355()
{
    return 3676884617U;
}

void setval_125(unsigned *p)
{
    *p = 3286272329U;
}

unsigned addval_310(unsigned x)
{
    return x + 3465109004U;
}

unsigned addval_151(unsigned x)
{
    return x + 3252717896U;
}

unsigned getval_186()
{
    return 3281044105U;
}

unsigned addval_445(unsigned x)
{
    return x + 2447411528U;
}

unsigned addval_484(unsigned x)
{
    return x + 3286288712U;
}

unsigned addval_285(unsigned x)
{
    return x + 3531915913U;
}

unsigned addval_345(unsigned x)
{
    return x + 2425471625U;
}

unsigned getval_361()
{
    return 2429471094U;
}

void setval_485(unsigned *p)
{
    *p = 3372794497U;
}

void setval_276(unsigned *p)
{
    *p = 3375943297U;
}

unsigned addval_115(unsigned x)
{
    return x + 3224424841U;
}

unsigned addval_368(unsigned x)
{
    return x + 3675836041U;
}

unsigned getval_109()
{
    return 3374367368U;
}

unsigned addval_317(unsigned x)
{
    return x + 2447411528U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
