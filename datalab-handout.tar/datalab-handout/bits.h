
int isTmax(int);
int test_isTmax(int);
int bitAnd(int, int);
int test_bitAnd(int, int);
int copyLSB(int);
int test_copyLSB(int);
int anyEvenBit();
int test_anyEvenBit();
int logicalNeg(int);
int test_logicalNeg(int);
int rempwr2(int, int);
int test_rempwr2(int, int);
int multFiveEighths(int);
int test_multFiveEighths(int);
int tc2sm(int);
int test_tc2sm(int);
